from setuptools import setup

setup(
    name="geotechtoolkit",
    author="Lucas Fabbri",
    author_email="lucafabbri18@gmail.com",
    version="0.0.1",
    packages=["geotechtoolkit"],
)
