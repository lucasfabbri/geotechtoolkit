from setuptools import setup, find_packages

setup(
    name="geotechtoolkit",
    author="Lucas Fabbri",
    author_email="lucafabbri18@gmail.com",
    version="0.0.1",
    packages=find_packages()
)
