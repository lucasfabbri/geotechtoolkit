MAX_ELEVATION = 8800
MIN_ELEVATION = -2000

FEATURE_STYLES = {
    "Bedrock": {
        "disc": {"inner": 0, "outer": 1},
        "plot": {"color": "black", "opacity": 0.7},
    }
}
